package com.backend.sagev;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SagevApplication {

	public static void main(String[] args) {
		SpringApplication.run(SagevApplication.class, args);
	}

}
